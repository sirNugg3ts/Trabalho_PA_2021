package pt.isec.a2018019825.jogo.logica;

public enum Operacao {
    SOMA,SUB,MULT,DIV
}
