package pt.isec.a2018019825.jogo.iu.gui;

public class ConstantesGUI {

    private ConstantesGUI(){}

    public static boolean SpecialMode = false;

    //PROPRIEDADES
    public static final String PROPRIEDADE_JOGO = "JOGO";
    public static final String PROPRIEDADE_INGAME = "INGAME";
    public static final String PROPRIEDADE_PLAYPIECE = "PLAYPIECE";
    public static final String PROPRIEDADE_CHOOSEMINIGAME = "ESCOLHAMINIJOGO";
    public static final String CANCELA_JOGADA = "CANCELAJOGADA";
    public static final String PROPRIEDADE_ENDMINIGAME = "ENDMINIGAME" ;
    public static final String RESPONDEMINIGAME = "MINIGAME" ;
    public static final String CANCELA_VOLTARATRAS = "CANCELAVOLTARATRAS";
    public static final String VOLTARATRAS = "VOLTARATRAS";
    public static final String COMECANOVOJOGO = "COMECANOVOJOGO";
    public static final String PROPRIEDADE_CARREGAJOGO = "CARREGAJOGO" ;
    public static final String REPLAY = "REPLAY" ;



}
